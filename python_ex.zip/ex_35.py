a = range(5)
print(a)        # rage(0, 5)
b = list(range(5))
print(b)
b = list(range(0,5))
print(b)
c = list(range(0,10,2))         #2씩 증가 값 
print(c)
c = list(range(0,10+1))         #연산 값 10+1 = 11
print(c)
# c = list(range(0,10/3))         #TypeError    실수연산 제외
# print(c)
c = list(range(0,10*3))      
print(c)
c = list(range(0,10//3))         # [0,1,2]
print(c)


