a = input(">1")
b = input(">2")
print()
#a=int(a)
#b=int(b)
#print(a,"+", b,"=", a + b)

print("{}+{}={}".format(a,b,int(a)+int(b)))

