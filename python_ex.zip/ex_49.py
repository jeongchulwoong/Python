
for i in range(0,5) :
    number = int(input(">정수 입력 : "))

    if number % 2 == 0 :
        print("{} : 짝수입니다.".format(number))
    else : 
        print("{} : 홀수입니다.".format(number)) 