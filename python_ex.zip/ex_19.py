number = input(">정수입력")
#1234   4567
last_character = number[-1]
last_character = int(last_character)

if (last_character % 2) == 0:
    print("짝수 입니다")
else :
    print("홀수 입니다")
    
#elif

