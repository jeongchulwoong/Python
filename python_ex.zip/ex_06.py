print(52.273)
print(273)
print(type(52))     #int
print(type(52.273))
print("5+7=", 5+7)
print("3/2", 3//2)  #숫자를 나누고 소수점이하 자리수 삭제후 정수만 출력
print("5%2=", 5%2)  #나머지
print("2**2=", 2**2**2) #거듭제곱
