hello="안녕하세요"
print(hello)
number=100
print(number)       #타입이 존재하지 않음
print(hello[0:2])   #slicing
print("안녕하세요"[3])  #indexing
print("안녕하세요"[5])  #indexingErorr
print(len("안녕하세요"))     #문자열의 길이(개수)
print("안녕하세요"[1:3])    #범위 지정
