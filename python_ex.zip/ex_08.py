number = 100
number += 10    #복합 대입 연산자
number -= 10
print(number)
print()
number = 5
number *= 5
print(number)
print()

number = 5
number **= 5
print(number)
print()

string="안녕하세요"
string +="!"
string +="!"
print("string:", string)