number = input("정수 입력> ")
number = int(number)

if number > 0 :
    print("양수입니다")
    
if number < 0 :
    print("음수입니다")
if number == 0 :
    print("0입니다")