print("Hello Coding Python")
print("Hello Coding Py")
print("Hello!" * 3)
#주석표시입니다.
print(1+1)
print(52,276,"Hello")
print("안녕", "하세요")

