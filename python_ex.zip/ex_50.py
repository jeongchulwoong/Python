test = (
    "이렇게 입력해도 "
    "하나의 문자열로 연결됩니다"
    "생성됩니다"
)

print("test : ", test)
print("type(test) :", type(test))
print(test + "문장을 자주 사용합니다.")