string="문자열"
print(type(string))
print("문자열")
number = 273
#print(string+number)    #typeErorr
print("안녕"+"하세요" * 3)
print(("안녕"+"하세요") * 3)

#변수는 모든 자료형을 저장

pi = 3.14259
print("pi=", pi)
pi = 200
print("pi=", pi)
pi="3.14159"
print("pi=", pi)