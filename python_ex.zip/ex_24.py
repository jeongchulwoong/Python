list_e = [52,273,103,275,1,7]
list_e.sort()
print(list_e)

list_e.reverse()
print(list_e)

#in 연산자 : 특정값이 리스트 내부에 있는지 확인
print(273 in list_e)
print(100 in list_e)
print()
# not in 연산자 : 특정값이 리스트 내부에 없는지 확인
print(100 not in list_e)
print(7 not in list_e)
