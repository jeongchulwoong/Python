key_list = ["name", "hp", "mp", "level"]
value_list = ["기사", 200, 30, 5]
charater = {}

for i in range(0,len(key_list)) :
    charater[key_list[i]] = value_list[i]
   # print(charater[key_list[i]])
    print(charater.keys())
print(charater)
print(charater.keys())
