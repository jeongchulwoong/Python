while True :
    print(".", end = "")    #줄바꿈이 일어나지 않는다