numbers = [5,15,6,20,7,25]

#for, coutinue
i = 1
for number in numbers:
    if number < 10:
        continue
    print(number)
    