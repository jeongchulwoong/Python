numbers = [1,2,3,4,5,6]
r_num = list(reversed(numbers))

print("reversed_number : ", r_num)

# print(next(r_num))          #리버스의 값을 가지고옴
# print(next(r_num))
# print(next(r_num))
# print(next(r_num))
# print(next(r_num))
# print(next(r_num))

#iterable 객체에 있는 interator