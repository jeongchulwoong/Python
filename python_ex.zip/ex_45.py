list_a = [1,2,3,4,5]
list_reversed = list(reversed(list_a))      #list로 반복자 즉 리버스한 것을 다시 리스트로 변환해야함

                #Python의 list() 함수는 iterable에서 목록 객체를 생성하거나 
                #다른 시퀀스와 유사한 객체를 목록으로 변환하는 데 사용되는 내장 함수입니다.
                #Iterable을 인수로 취하고 iterable의 요소를 포함하는 새 목록을 반환합니다.

print("list_a", list_a)
print("#reversed()함수")
print("revered([1,2,3,4,5]) : ", list_reversed)

