raw_input = input("inch단위의 숫자를 입력해주세요 :")
inch = int(raw_input)
cm = inch*2.54

print(inch,"inch는 cm단위로 ", cm, "cm입니다")