print(10 == 100)        #boolean True False
print(10 != 100)
print("가방" < "하마")
print(not True)
print(True and True)
print(True or False)

if True:
    print("True입니다...!")
    print("정말 True입니다...!")
print("조건문")